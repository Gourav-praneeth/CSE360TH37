package application;

public class EffortLogConsole {
   
}
